<?php
declare(strict_types=1);

require_once __DIR__ . '/../helpers/cors.php';
require_once __DIR__ . '/../helpers/response.php';
require_once __DIR__ . '/../helpers/request.php';
require_once __DIR__ . '/../middleware/auth.php';
require_once __DIR__ . '/../config/database.php';

send_cors_headers();

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') error_response('Method not allowed', 405);

$payload = require_member();
$data = read_json_body();
$pdo = db();

$stmt = $pdo->prepare('SELECT * FROM doctors WHERE id = :id LIMIT 1');
$stmt->execute(['id' => $payload['id']]);
$current = $stmt->fetch();
if (!$current) error_response('Profile not found', 404);

$fields = [
    'name' => str_value($data['name'] ?? $current['name']),
    'title' => str_value($data['title'] ?? $current['title']),
    'academic_title' => str_value($data['academic_title'] ?? $current['academic_title']),
    'medical_school_affiliation' => str_value($data['medical_school_affiliation'] ?? $current['medical_school_affiliation']),
    'specialty' => str_value($data['specialty'] ?? $current['specialty']),
    'subspecialty' => str_value($data['subspecialty'] ?? $current['subspecialty']),
    'graduation_degree' => str_value($data['graduation_degree'] ?? $current['graduation_degree']),
    'graduation_year' => int_value($data['graduation_year'] ?? $current['graduation_year']),
    'location' => str_value($data['location'] ?? $current['location']),
    'practice' => str_value($data['practice'] ?? $current['practice']),
    'address' => str_value($data['address'] ?? $current['address']),
    'hospital_affiliations' => str_value($data['hospital_affiliations'] ?? $current['hospital_affiliations']),
    'phone' => str_value($data['phone'] ?? $current['phone']),
    'bio' => str_value($data['bio'] ?? $current['bio']),
    'education' => str_value($data['education'] ?? $current['education']),
    'experience' => str_value($data['experience'] ?? $current['experience']),
    'languages' => str_value($data['languages'] ?? $current['languages']),
    'awards' => str_value($data['awards'] ?? $current['awards']),
    'profile_visibility' => str_value($data['profile_visibility'] ?? $current['profile_visibility']),
    'accepting_patients' => bool_value($data['accepting_patients'] ?? $current['accepting_patients']),
];

$sql = 'UPDATE doctors SET name=:name, title=:title, academic_title=:academic_title, medical_school_affiliation=:medical_school_affiliation, specialty=:specialty, subspecialty=:subspecialty, graduation_degree=:graduation_degree, graduation_year=:graduation_year, location=:location, practice=:practice, address=:address, hospital_affiliations=:hospital_affiliations, phone=:phone, bio=:bio, education=:education, experience=:experience, languages=:languages, awards=:awards, profile_visibility=:profile_visibility, accepting_patients=:accepting_patients, updated_at=NOW() WHERE id=:id';
$params = $fields + ['id' => $payload['id']];
$upd = $pdo->prepare($sql);
$upd->execute($params);

json_response(['success' => true, 'message' => 'Profile updated successfully']);
